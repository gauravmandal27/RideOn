package com.src.service;

import com.src.model.Partners;
import com.src.model.Rides;

public interface RideServiceInterface{
public Partners getPartner(double fare,double distance);
public Rides getRide(String start,String drop);
}
