package com.src.service;

import com.src.model.Partners;
import com.src.model.Rides;

public class RideServiceClass implements RideServiceInterface {

	@Override
	public Partners getPartner(double fare, double distance) {
		
		return null;
	}

	@Override
	public Rides getRide(String start, String drop) {
		// TODO Auto-generated method stub
		return null;
	}

}
