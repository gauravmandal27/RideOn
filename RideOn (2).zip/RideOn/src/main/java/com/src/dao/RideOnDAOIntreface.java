package com.src.dao;

import java.util.ArrayList;

import com.src.model.Partners;

public interface RideOnDAOIntreface{
	public boolean creatDatabase();
	public boolean executeStatement(String query);
	public ArrayList<Partners> getPartnerdb();
}
