package com.src.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.src.model.Partners;

public  class RideOnDAOImplementation implements RideOnDAOIntreface{
	Connection con = null;
	Statement stmt = null;
	
	public Statement getMyStatement() {
		String url ="jdbc:mysql://localhost:3306/RideON";
		String username = "root";
		String password = "Gaurav@02";
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection(url, username, password);
			stmt=con.createStatement();
		} catch (ClassNotFoundException exception) {
			exception.printStackTrace();
		} catch (SQLException exception) {
			exception.printStackTrace();
		}
		return stmt;	
	}


	public void closeConnections() {
		
		try {
			con.close();
			stmt.close();
		} catch (SQLException exception) {
			exception.printStackTrace();
		}
		
	}
	
	@Override
	public boolean creatDatabase() {
		getMyStatement();
		String query = "create database";
		boolean bo=false;
		try {
			bo = stmt.execute(query);
			System.out.println(query+bo);
		} catch (SQLException exception) {
			exception.printStackTrace();
		}
		closeConnections();
		return bo;
		
	}


	@Override
	public boolean executeStatement(String query) {
		getMyStatement();
		boolean result = false;
		try {
			result = stmt.execute(query);
		} catch (SQLException exception) {
			exception.printStackTrace();
		}
		closeConnections();
		return result;
	}



	@Override
	public ArrayList<Partners> getPartnerdb() {
		stmt = getMyStatement();
		
		return null;
	}

}
