package com.src.dao;

public class MainMethod {

	public static void main(String[] args) {
		RideOnDAOIntreface ride = new RideOnDAOImplementation();
		System.out.println(ride.creatDatabase());
	}

}
