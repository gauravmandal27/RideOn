package com.src.reflection;

import java.lang.module.ModuleDescriptor.Modifier;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;

import com.src.dao.RideOnDAOImplementation;
import com.src.dao.RideOnDAOIntreface;
import com.src.model.Rides;

public class DatabaseCreatorUsingReflection {
	public String containsContraint(Field individualField,Object o){
		String nameOfField = individualField.getName();
		if(nameOfField.contains("isConstraintPrimaryKey")) {
			return " primary key";
		}
		else if(nameOfField.contains("isConstraintNotNull")) {
			return " NOT NULL";
		}
		else if(nameOfField.contains("isConstraintUnique")) {
			return " Unique";
		}
		else if(nameOfField.contains("isConstraintForeignKey")) {
			try {
				individualField.setAccessible(true);
				Field k = individualField;
//				System.out.println(" Foreign Key REFERENCES "+(String)k.get();
				Class cls1 = individualField.getClass();
				return " REFERENCES "+k.get(o);
			} catch (SecurityException e){
				e.printStackTrace();
			} catch (IllegalArgumentException e) {
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				e.printStackTrace();
			}
		}
		else if(nameOfField.contains("isConstraintDefault")){
			individualField.setAccessible(true);
			try {
				return " default = '"+individualField.getByte(o)+"' ";
			} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if(nameOfField.contains("isConstraintCheck")) {
			String possibleValues=" ";
			individualField.setAccessible(true);
			try {
				possibleValues =(String) individualField.get(o);
			} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			String result ="CHECK(";
			String[] values = possibleValues.split(",");
			int noOfChecks = values.length;
			String nameCons= individualField.getName();
			nameCons=nameCons.replaceFirst("isConstraintCheck","");
			for(int i=0;i<noOfChecks;i++) {
				if(i==0){
					result+=nameCons+"='"+values[0]+"'";
				}
				else {
		
					result+=" or "+nameCons+"='"+values[i]+"'";
				}
			}
			result+=")";
			return result;
		}
		else if(nameOfField.contains("isConstraintAutoIncrement")){
			return " Auto_Increment";
		}
		return "";
	}
	
	public String dataTypeSupplier(String dataType) {
//		System.out.println("Type is"+dataType);
		if(dataType.equals("int")) {
			return "int";
		}
		else if(dataType.equals("long")) {
			return "bigint";
		}
		else if(dataType.equals("double")) {
			return "double";
		}
		else if(dataType.contains("LocalDateTime")) {
			return "timestamp";
		}
		else if(dataType.equals("java.lang.String")) {
			return "varchar(30)";
		}
		else if(dataType.equals("short")) {
			return "smallint";
		}

		return "varchar(30)";	
	}
	public boolean CreateUsingClass(String className) throws ClassNotFoundException{
		Class class1 = Class.forName(className);
		Object c=null;
		try {
			c = class1.newInstance();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String query1 = "Drop table if exists "+class1.getSimpleName();
		String query="create table "+class1.getSimpleName();
		Field[] fieldsArray = class1.getDeclaredFields();
		boolean check = false;
		for(Field individualField:fieldsArray) {
			String nameOfField = individualField.getName();
			if(nameOfField.contains("isConstraint")){
				check = true;
				String constraint = containsContraint(individualField,c);
				query = query.concat(" "+constraint+" ");
				continue;
			}
			if(check==true) {
				check = false;
//				System.out.println(nameOfField+" "+individualField.getType().getTypeName());
				String type = dataTypeSupplier(individualField.getType().getTypeName());
				query = query.concat(","+nameOfField+" "+type+" ");
			}
			else {
			if(!check){
				query = query .concat(",");
			}
			query = query.concat(nameOfField+" "+dataTypeSupplier(individualField.getType().getTypeName()));
			}
		}
		query = query.concat(")");
		query = query.replaceFirst(",","(");
		RideOnDAOIntreface ride = new RideOnDAOImplementation();
		System.out.println(query1+"\n"+query);
		ride.executeStatement(query1);
		ride.executeStatement(query);
		return false;
	}
	public static void main(String[] args) throws ClassNotFoundException {
		DatabaseCreatorUsingReflection ref = new DatabaseCreatorUsingReflection();
//		ref.CreateUsingClass("com.src.model.Customers");
//		ref.CreateUsingClass("com.src.model.Partners");
//		ref.CreateUsingClass("com.src.model.Rides");
		ref.CreateUsingClass("com.src.model.Users");
	}
}
