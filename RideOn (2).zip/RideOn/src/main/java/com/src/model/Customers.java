package com.src.model;

import java.time.LocalDateTime;

public class Customers {
	private String customerFirstName;
	private String customerLastName;
	private String customerEmail;
	private final static boolean isConstraintPrimaryKeyCustomerEmail = true;
	private long customerMobile;
	private final static boolean isConstraintNotNullCustomerMobile = true;
	private int customerNoOfRides;
	private double customerRating;
	private LocalDateTime customerDOJ;
	private String customerPassword;
	private final static boolean isConstraintNotNullCustomerPassword = true;
}
