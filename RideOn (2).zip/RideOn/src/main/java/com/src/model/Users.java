package com.src.model;

public class Users {
private String userID;
private boolean isConstraintPrimaryKeyUserID = true;
private String userPassword;
private String userType;
private String isConstraintCheckuserType="Admin,Customer,Partner";

}
