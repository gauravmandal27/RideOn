package com.src.model;

import java.time.LocalDateTime;

public class Rides {
private long rideID;
private final  boolean isConstraintPrimaryKeyRideID = true;
private final  boolean isConstraintAutoIncrementRideID = true;
private String rideOrigin;
private String rideDestination;
private double rideFare;
private String customerEmail;
private final  String isConstraintForeignKeyCustomerEmail= "Customers(customerEmail)";
private String partnerEmail;
private String isConstraintForeignKeyPartnerEmail= "Partners(partnerEmail)";
private LocalDateTime rideDateTime;

public long getRideID() {
	return rideID;
}
public void setRideID(long rideID) {
	this.rideID = rideID;
}
public Rides() {
}
public Rides(long rideID, String rideOrigin, String rideDestination, double rideFare, String customerEmail,
		String partnerEmail, LocalDateTime rideDateTime) {
	super();
	this.rideID = rideID;
	this.rideOrigin = rideOrigin;
	this.rideDestination = rideDestination;
	this.rideFare = rideFare;
	this.customerEmail = customerEmail;
	this.partnerEmail = partnerEmail;
	this.rideDateTime = rideDateTime;
}
public String getRideOrigin() {
	return rideOrigin;
}
public void setRideOrigin(String rideOrigin) {
	this.rideOrigin = rideOrigin;
}
public String getRideDestination() {
	return rideDestination;
}
public void setRideDestination(String rideDestination) {
	this.rideDestination = rideDestination;
}
public double getRideFare() {
	return rideFare;
}
public void setRideFare(double rideFare) {
	this.rideFare = rideFare;
}
public String getCustomerEmail() {
	return customerEmail;
}
public void setCustomerEmail(String customerEmail) {
	this.customerEmail = customerEmail;
}
public String getPartnerEmail() {
	return partnerEmail;
}
public void setPartnerEmail(String partnerEmail) {
	this.partnerEmail = partnerEmail;
}
public LocalDateTime getRideDateTime() {
	return rideDateTime;
}
public void setRideDateTime(LocalDateTime rideDateTime) {
	this.rideDateTime = rideDateTime;
}
public  boolean isPrimaryKeyRideID(){
	return isConstraintPrimaryKeyRideID;
}
public boolean isIsautoincrementrideid() {
	return isConstraintAutoIncrementRideID;
}

}
