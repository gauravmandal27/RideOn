package com.src.model;
import java.time.LocalDateTime;

public class Partners{
private String partnerFirstName;
private String partnerLastName;
private String partnerEmail;
private final static boolean isConstraintPrimaryKeyPartnerEmail = true;
private long partnerMobile;
private final static boolean isConstraintNotNullPartnerMobile = true;
private int partnerNoOfRides;
private double partnerRating;
private double partnerTotalEarning;
private String partnerStatus; 
private String isConstraintcheckPartnerStatus ="Online,Offline,Reserved";
private String VehicleMakeModel;
private String VehicleType;
private String VehicleRegistrationNumber;
private LocalDateTime partnerDOJ;
private String partnerPassword;
}